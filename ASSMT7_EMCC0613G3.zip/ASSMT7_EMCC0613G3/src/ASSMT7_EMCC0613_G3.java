import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Event;
import java.awt.Font;
import java.awt.image.BufferedImage;

public class ASSMT7_EMCC0613_G3 extends java.applet.Applet implements Runnable {
    
    Image borderD, borderU, borderL, borderR, fenceD, fenceU, fenceL, fenceR, obs1, 
            obs2, obs3, obs4, obs5, obs6, obs7, obs8, obs9, obs10, obs11, obs12, 
            hart, dogU, dogD, dogR, dogL, RST, maze, congrats, gameOver, bgL, bgR, pathU, pathLR, pathD;

    BufferedImage offScreenImage;
    Graphics offScreenGraphics;
    
    Thread timer;

    char currkey;
    int x = 610;
    int y = 75;
    int lives = 3; // Initial number of lives

    Image currImage;
    Image charac[] = new Image[5];
    


    public void start() {
        if (timer == null);
        timer = new Thread(this);
        timer.start();
    }

    public void stop() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
    }

    void pause(int time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public boolean keyDown(Event evt, int key) {
        switch (key) {
            case Event.DOWN:
            case 'S':
            case 's':
                currkey = 'S';
                break;
            case Event.UP:
            case 'W':
            case 'w':
                currkey = 'W';
                break;
            case Event.LEFT:
            case 'A':
            case 'a':
                currkey = 'A';
                break;
            case Event.RIGHT:
            case 'D':
            case 'd':
                currkey = 'D';
                break;
            case 88:
                currkey = 'X';
                break;
        }
        return true;
    }
    
        boolean hitObstacle = false;
        boolean allowMovement = true;

    public void hitObstacle() {
        allowMovement = false;  // Stop move
        hitObstacle = true;
        lives--; // decra

        if (lives <= 0) {
            gameOver(); // gameover scrn
        } else {
            // 2sc
            pause(2000);

            // Reset image and position
            currImage = charac[4];
            x = 610;
            y = 75;

            currkey = 'X';

            allowMovement = true;
            hitObstacle = false;
            repaint();
        }
    }

    boolean gameOverFlag = false;

    public void gameOver() {
        gameOverFlag = true;
        stop(); // Stop the game
    }
    
   public void run() {
    while (lives > 0) {
        if (allowMovement) {
            switch (currkey) {
                case 'W':
                    y -= 8;
                    changeImage('W');
                    break;
                case 'S':
                    y += 8;
                    changeImage('S');
                    break;
                case 'A':
                    x -= 8;
                    changeImage('A');
                    break;
                case 'D':
                    x += 8;
                    changeImage('D');
                    break;
                    case 88:
                currkey = 'X';
                break;
                default:
                    currImage = charac[4]; // RST
                    break;
            }

            
            repaint();
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
            ///obs1
            if ((y >= 95) && (y <= 230) && (x >= 650) && (x < 894)) // t b l r
            {hitObstacle();}
            
            //obs2
            if ((y >= 170) && (y <= 345) && (x >= 650) && (x < 795)) 
            {hitObstacle();}
            
            //obs 3
            if ((y >= 640) && (y <= 790) && (x >= 550) && (x < 699))
            {hitObstacle();}
            
            //obs 4
            if ((y >= 420) && (y <= 680) && (x >= 650) && (x < 792)) // t b l r
            {hitObstacle();}
            
            //obs 5
            if ((y >= 420) && (y <= 577) && (x >= 858) && (x < 996))
            {hitObstacle();}
            
            //obs 6
            if ((y >= 315) && (y <= 455) && (x >= 858) && (x < 1098))
            {hitObstacle();}
            
            //obs 7
            if ((y >= 95) && (y <= 235) && (x >= 960) && (x < 1195)) // t b l r
            {hitObstacle();}
            
            //obs 8
            if ((y >= 1) && (y <= 455) && (x >= 1150) && (x < 1300))
            {hitObstacle();}
            
            //obs 9
            if ((y >= 532) && (y <= 670) && (x >= 1060) && (x < 1300))
            {hitObstacle();}
        
            //obs 10
            if ((y >= 640) && (y <= 790) && (x >= 854) && (x < 1100)) // t b l r
            {hitObstacle();}
            
            //obs11
            if ((y >= 740) && (y <= 916) && (x >= 752) && (x < 900))
            {hitObstacle();}
            
            //obs12
            if ((y >= 740) && (y <= 916) && (x >= 1160) && (x < 1408))
            {hitObstacle();}
            
            else if ((x > 1400)) { //FINISHLINE
                    stop();}
            
}}}


    
    public void init() {

        String dogpath[] = {"dogU.gif", "dogD.gif", "dogL.gif", "dogR.gif", "RST.png"}; // for character movement 
        
        for (int i = 0; i < charac.length; i++) {
            charac[i] = getImage(getCodeBase(), "images/" + dogpath[i]);
            Image tempImg = getImage(getCodeBase(), "images/" + dogpath[i]);
            int newWidth = 50;
            int newHeight = 60;
            tempImg = tempImg.getScaledInstance(newWidth, newHeight, Image.SCALE_DEFAULT);
            charac[i] = tempImg;
        }
        
        borderD = getImage(getCodeBase(), "images/borderD.png");
        borderU = getImage(getCodeBase(), "images/borderU.png");
        borderL = getImage(getCodeBase(), "images/borderL.png");
        borderR = getImage(getCodeBase(), "images/borderR.png");
        fenceD = getImage(getCodeBase(), "images/fenceD.png");
        fenceU = getImage(getCodeBase(), "images/fenceU.png");
        fenceL = getImage(getCodeBase(), "images/fenceL.png");
        fenceR = getImage(getCodeBase(), "images/fenceR.png");
        obs1 = getImage(getCodeBase(), "images/obs1.png");
        obs2 = getImage(getCodeBase(), "images/obs2.png");
        obs3 = getImage(getCodeBase(), "images/obs3.png");
        obs4 = getImage(getCodeBase(), "images/obs4.png");
        obs5 = getImage(getCodeBase(), "images/obs5.png");
        obs6 = getImage(getCodeBase(), "images/obs6.png");
        obs7 = getImage(getCodeBase(), "images/obs7.png");
        obs8 = getImage(getCodeBase(), "images/obs8.png");
        obs9 = getImage(getCodeBase(), "images/obs9.png");
        obs10 = getImage(getCodeBase(), "images/obs10.png");
        obs11 = getImage(getCodeBase(), "images/obs11.png");
        obs12 = getImage(getCodeBase(), "images/obs12.png");
        maze = getImage(getCodeBase(), "images/maze.png");
        hart = getImage(getCodeBase(), "images/hart.png");
        bgR = getImage(getCodeBase(), "images/bgR.png");
        bgL = getImage(getCodeBase(), "images/bgL.png");
        gameOver = getImage(getCodeBase(), "images/gameOver.png");
        congrats = getImage(getCodeBase(), "images/congrats.png");
        pathU = getImage(getCodeBase(), "images/pathU.png");
        pathD = getImage(getCodeBase(), "images/pathD.png");
        pathLR = getImage(getCodeBase(), "images/pathLR.png");
        
        setBackground(Color.white);
        createOffScreenImage();
        }
    
    public void createOffScreenImage() {
        offScreenImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
        offScreenGraphics = offScreenImage.getGraphics();
    }
               
         public void update(Graphics g) {
            paint(g);
         }
        
    public void paint (Graphics g) {
        createOffScreenImage();
        offScreenGraphics.clearRect(0, 0, getWidth(), getHeight());
        
        Color fillColor1 = Color.decode("#C0D470");
        offScreenGraphics.setColor(fillColor1);
        offScreenGraphics.fillRect(0,0,2500,2500);
        
       // g.drawImage(maze, 500, 40, 1000, 900, this); // x y w h
        
        //paths n hart
        offScreenGraphics.drawImage(hart, 1510, 135, 150, 200, this); // x y w h
        
        offScreenGraphics.drawImage(pathU, 300, 40, 1500, 180, this);
        
        offScreenGraphics.drawImage(pathLR, 625, 125, 50, 200, this);
        offScreenGraphics.drawImage(pathLR, 625, 325, 50, 200, this);
        offScreenGraphics.drawImage(pathLR, 625, 525, 50, 200, this);
        
        offScreenGraphics.drawImage(pathLR, 1330, 125, 50, 200, this);
        offScreenGraphics.drawImage(pathLR, 1330, 325, 50, 200, this);
        offScreenGraphics.drawImage(pathLR, 1330, 525, 50, 280, this);
        
        offScreenGraphics.drawImage(pathD, 600, 833, 200, 50, this);
        offScreenGraphics.drawImage(pathD, 903, 833, 300, 50, this);
        //dog image
        offScreenGraphics.drawImage(currImage, x, y, this);
        
        //border
        offScreenGraphics.drawImage(borderD, 500, 870, 1000, 100, this); // x y w h
        offScreenGraphics.drawImage(borderU, 515, -20, 990, 100, this); // x y w h
        offScreenGraphics.drawImage(borderL, 435, 130, 200, 800, this); // x y w h
        offScreenGraphics.drawImage(borderR, 1370, 130, 200, 800, this); // x y w h
        
        //fences
        offScreenGraphics.drawImage(fenceU, 575, -20, 865, 140, this); // x y w h
        offScreenGraphics.drawImage(fenceL, 520, 100, 140, 865, this); // x y w h
        offScreenGraphics.drawImage(fenceR, 1345, 100, 140, 865, this); // x y w h
        
        //OBS1
        offScreenGraphics.drawImage(obs1, 680, 130, 240, 130, this); // x y w h
        
        //OBS2
        offScreenGraphics.drawImage(obs2, 680, 270, 150, 100, this); // x y w h
        
        //OBS3
        offScreenGraphics.drawImage(obs3, 575, 650, 160, 170, this); // x y w h
        
        //OBS4
        offScreenGraphics.drawImage(obs4, 660, 465, 190, 200, this); // x y w h
        offScreenGraphics.drawImage(obs4, 660, 510, 190, 200, this); // x y w h
        
        //OBS5
        offScreenGraphics.drawImage(obs5, 878, 442, 150, 200, this); // x y w h
        
        //OBS6
        offScreenGraphics.drawImage(obs6, 868, 260, 270, 347, this); // x y w h
        
        //OBS7
        offScreenGraphics.drawImage(obs7, 960, 95, 290, 200, this); // x y w h
        
        //OBS8
        offScreenGraphics.drawImage(obs8, 1130, 0, 250, 500, this); // x y w h
        
        //OBS9
        offScreenGraphics.drawImage(obs9, 1065, 540, 280, 200, this); // x y w h
        
        //OBS10
        offScreenGraphics.drawImage(obs10, 880, 660, 250, 180, this); // x y w h
        
        //OBS11
        offScreenGraphics.drawImage(obs11, 790, 770, 130, 170, this); // x y w h
        
        //OBS12
        offScreenGraphics.drawImage(obs12, 1190, 790, 230, 130, this); // x y w h
        
        // fence
        offScreenGraphics.drawImage(fenceD, 575, 855, 865, 145, this); // x y w h
        
        //outside maze design
        offScreenGraphics.drawImage(bgR, 1480, 0, 600, 1000, this); // x y w h
        offScreenGraphics.drawImage(bgL, 0, 0, 520, 940, this); // x y w h
        
        //#F15D43
         Font f1 = new Font("Times New Roman", Font.BOLD, 50);
         offScreenGraphics.setFont(f1);
         offScreenGraphics.setColor(Color.BLACK);
         offScreenGraphics.drawString(" " + lives, 1560, 315);
         
         
        if(gameOverFlag) {
        offScreenGraphics.drawImage(gameOver, 800, 300, this);}
        else if (x > 1400) 
        {offScreenGraphics.drawImage(congrats, 800, 300, this);}
        
        g.drawImage(offScreenImage, 0, 0, this);
         }
        
    public void changeImage(char direction) {
        switch (direction) {
            case 'W':
                currImage = charac[0]; 
                break;
            case 'S':
                currImage = charac[1]; 
                break;
            case 'A':
                currImage = charac[2]; 
                break;
            case 'D':
                currImage = charac[3]; 
                break;
            case 88:
                currImage = charac[4]; 
                break;
        }
        
    }

}

    
